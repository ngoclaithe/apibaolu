package com.example.smartgarden.ui.chart;

import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.smartgarden.R;
import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.Description;

import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;

import java.util.ArrayList;

public class ChartFragment extends Fragment {

    private LineChart lineChart1, lineChart2;
    private ArrayList<Entry> tempEntries;
    private ArrayList<Entry> humiEntries;
    private LineDataSet dataSet1, dataSet2;
    private LineData lineData1, lineData2;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_chart, container, false);
        lineChart1 = view.findViewById(R.id.lineChart1);
        lineChart2 = view.findViewById(R.id.lineChart2);

        Bundle bundle = getArguments();
        if (bundle != null) {
            tempEntries = bundle.getParcelableArrayList("tempEntries");
            humiEntries = bundle.getParcelableArrayList("humiEntries");
            if (tempEntries != null && humiEntries != null && !tempEntries.isEmpty() && !humiEntries.isEmpty()) {
                dataSet1 = new LineDataSet(tempEntries, "Nhiệt độ");
                dataSet1.setColor(Color.RED);
                dataSet1.setCircleColor(Color.RED);
                dataSet1.setLineWidth(2f);
                dataSet1.setCircleRadius(4f);
                dataSet1.setDrawCircleHole(false);
                dataSet1.setDrawValues(false);
                dataSet1.setMode(LineDataSet.Mode.CUBIC_BEZIER);

                lineData1 = new LineData(dataSet1);
                lineChart1.setData(lineData1);

                dataSet2 = new LineDataSet(humiEntries, "Độ ẩm");
                dataSet2.setColor(Color.BLUE);
                dataSet2.setCircleColor(Color.BLUE);
                dataSet2.setLineWidth(2f);
                dataSet2.setCircleRadius(4f);
                dataSet2.setDrawCircleHole(false);
                dataSet2.setDrawValues(false);
                dataSet2.setMode(LineDataSet.Mode.CUBIC_BEZIER);

                lineData2 = new LineData(dataSet2);
                lineChart2.setData(lineData2);

                lineChart1.invalidate();
                lineChart2.invalidate();

            } else {
                // Xử lý trường hợp dữ liệu trống
            }
        }

        return view;
    }

}

