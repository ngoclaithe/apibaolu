package com.example.smartgarden.ui.setting;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.smartgarden.R;
import com.example.smartgarden.databinding.FragmentSettingBinding;

public class SettingFragment extends Fragment {

    private FragmentSettingBinding binding;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentSettingBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        EditText editTextServerAddress = binding.editTextText;
        Button buttonSave = binding.button;

        // Load saved server address
        SharedPreferences sharedPreferences = requireContext().getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
        String savedServerAddress = sharedPreferences.getString("server_address", "");
        editTextServerAddress.setText(savedServerAddress);

        // Handle Save button click
        buttonSave.setOnClickListener(v -> {
            String serverAddress = editTextServerAddress.getText().toString();
            if (!serverAddress.isEmpty()) {
                saveServerAddress(serverAddress);
            }
        });

        return root;
    }

    private void saveServerAddress(String serverAddress) {
        SharedPreferences sharedPreferences = requireContext().getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("server_address", serverAddress);
        editor.apply();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}