package com.example.dubaolu.ui.dashboard;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.example.dubaolu.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class DashboardFragment extends Fragment {

    private LinearLayout dataContainer;
    private String serverAddress;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_dashboard, container, false);

        dataContainer = root.findViewById(R.id.container);

        SharedPreferences sharedPreferences = requireContext().getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
        serverAddress = sharedPreferences.getString("server_address", "");
        Log.d("serverAddress", serverAddress);
        requestDataForChart();
        return root;
    }

    private void requestDataForChart() {
        String url = serverAddress + "/get_data";
        Log.d("URL", url);

        Request request = new Request.Builder()
                .url(url)
                .build();

        OkHttpClient client = new OkHttpClient();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                e.printStackTrace();
                requireActivity().runOnUiThread(() -> Toast.makeText(requireContext(), "Failed to fetch data", Toast.LENGTH_SHORT).show());
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                String responseData = response.body().string();
                requireActivity().runOnUiThread(() -> {
                    handleChartResponse(responseData);
                });
            }
        });
    }

    private void handleChartResponse(String responseData) {
        try {
            dataContainer.removeAllViews();

            JSONObject jsonResponse = new JSONObject(responseData);
            JSONArray jsonArray = jsonResponse.getJSONArray("data");

            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObject = jsonArray.getJSONObject(i);
                String temperature = jsonObject.getString("temperature");
                String humidity = jsonObject.getString("humidity");
                String timestamp = jsonObject.getString("timestamp");

                View itemView = LayoutInflater.from(requireContext()).inflate(R.layout.data_detail, dataContainer, false);

                ImageView temperatureImageView = itemView.findViewById(R.id.temperature_image);
                ImageView humidityImageView = itemView.findViewById(R.id.humidity_image);
                ImageView timeImageView = itemView.findViewById(R.id.time_image);

                temperatureImageView.setImageResource(R.drawable.ic_temperature);
                humidityImageView.setImageResource(R.drawable.ic_humidity);
                timeImageView.setImageResource(R.drawable.ic_timestamp);

                TextView temperatureTextView = itemView.findViewById(R.id.temperature_text);
                TextView humidityTextView = itemView.findViewById(R.id.humidity_text);
                TextView timeTextView = itemView.findViewById(R.id.time_text);

                temperatureTextView.setText(temperature + "°C");
                humidityTextView.setText(humidity + "%");
                timeTextView.setText(timestamp);

                dataContainer.addView(itemView);
            }

        } catch (JSONException e) {
            e.printStackTrace();
            Toast.makeText(requireContext(), "Failed to process data", Toast.LENGTH_SHORT).show();
        }
    }

}
