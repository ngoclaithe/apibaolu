package com.example.smartgarden.ui.dashboard;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.navigation.Navigation;

import com.example.smartgarden.R;
import com.example.smartgarden.ui.chart.ChartFragment;
import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.data.Entry;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class DashboardFragment extends Fragment {

    private TableLayout tableLayout;
    private String serverAddress;
    private View statisticsForm;
    private boolean isStatisticsFormVisible = false;
    private EditText id_device_send_server;
    private BarChart barChart;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_dashboard, container, false);

        tableLayout = root.findViewById(R.id.tableLayout);
        statisticsForm = root.findViewById(R.id.statistics_form);
        id_device_send_server = statisticsForm.findViewById(R.id.editTextDeviceId);

        Button buttonStatistics = root.findViewById(R.id.buttonStatistics);
        Button buttonConfirm = statisticsForm.findViewById(R.id.buttonConfirm);

        buttonStatistics.setOnClickListener(v -> toggleStatisticsFormVisibility());

        EditText editTextFromDate = statisticsForm.findViewById(R.id.editTextDatePickerFrom);
        EditText editTextToDate = statisticsForm.findViewById(R.id.editTextDatePickerTo);
        editTextFromDate.setOnClickListener(this::showDatePicker);
        editTextToDate.setOnClickListener(this::showDatePicker);

        buttonConfirm.setOnClickListener(v -> handleViewChart());


        // Load server address from SharedPreferences
        SharedPreferences sharedPreferences = requireContext().getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
        serverAddress = sharedPreferences.getString("server_address", "");

        // Load data when fragment is created or reloaded
        loadData();

        return root;
    }


    private void handleViewChart() {
        String idDevice = id_device_send_server.getText().toString().trim();
        String fromDate = ((EditText) statisticsForm.findViewById(R.id.editTextDatePickerFrom)).getText().toString().trim();
        String toDate = ((EditText) statisticsForm.findViewById(R.id.editTextDatePickerTo)).getText().toString().trim();

        if (idDevice.isEmpty() || fromDate.isEmpty() || toDate.isEmpty()) {
            Toast.makeText(requireContext(), "Please fill all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        // Request data for the chart
        requestDataForChart(idDevice, fromDate, toDate);
    }


    private void requestDataForChart(String idDevice, String fromDate, String toDate) {
        String url = "http://" + serverAddress + ":8000/get_data_detail_device?id_dev=" + idDevice + "&from_date=" + fromDate + "&to_date=" + toDate;
        Log.d("URL", url);

        Request request = new Request.Builder()
                .url(url)
                .build();

        OkHttpClient client = new OkHttpClient();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                e.printStackTrace();
                requireActivity().runOnUiThread(() -> Toast.makeText(requireContext(), "Failed to fetch data", Toast.LENGTH_SHORT).show());
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                String responseData = response.body().string();
                requireActivity().runOnUiThread(() -> {
                    handleChartResponse(responseData);
                });
            }
        });
    }

    private void handleChartResponse(String responseData) {
        try {
            JSONArray jsonArray = new JSONArray(responseData);
            ArrayList<Entry> tempEntries = new ArrayList<>();
            ArrayList<Entry> humiEntries = new ArrayList<>();

            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObject = jsonArray.getJSONObject(i);
                String temp = jsonObject.getString("temp");
                String humi = jsonObject.getString("humi");
//                String time = jsonObject.getString("time");

//                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.getDefault());
//                Date date = sdf.parse(time);
//                long millis = date.getTime();

                Entry tempEntry = new BarEntry(i, Float.parseFloat(temp));
                Entry humiEntry = new BarEntry(i, Float.parseFloat(humi));

                tempEntries.add(tempEntry);
                humiEntries.add(humiEntry);

                // Log entry's x value
                Log.d("Entry", "X: " + tempEntry.getX()  + ", Temp: " + temp + ", Humi: " + humi);
            }

            Bundle bundle = new Bundle();
            bundle.putParcelableArrayList("tempEntries", tempEntries);
            bundle.putParcelableArrayList("humiEntries", humiEntries);
            Navigation.findNavController(requireView()).navigate(R.id.navigation_chart, bundle);
        } catch (JSONException e) {
            e.printStackTrace();
            Toast.makeText(requireContext(), "Failed to process data", Toast.LENGTH_SHORT).show();
        }
    }

    private void toggleStatisticsFormVisibility() {
        isStatisticsFormVisible = !isStatisticsFormVisible;
        statisticsForm.setVisibility(isStatisticsFormVisible ? View.VISIBLE : View.GONE);
    }

    private void loadData() {
        if (serverAddress.isEmpty()) {
            Toast.makeText(requireContext(), "Please set server address in settings", Toast.LENGTH_SHORT).show();
            return;
        }

        sendHttpRequest("http://" + serverAddress + ":8000/get_list_device");
    }

    private void sendHttpRequest(String url) {
        Request request = new Request.Builder()
                .url(url)
                .build();
        OkHttpClient client = new OkHttpClient();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                e.printStackTrace();
                if (isAdded()) {
                    requireActivity().runOnUiThread(() -> Toast.makeText(requireContext(), "Failed to fetch data", Toast.LENGTH_SHORT).show());
                }
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                String responseData = response.body().string();
                requireActivity().runOnUiThread(() -> {
                    try {
                        handleResponse(responseData);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                });
            }
        });
    }

    private void handleResponse(String responseData) throws JSONException {
        JSONArray jsonArray = new JSONArray(responseData);

        for (int i = 0; i < jsonArray.length(); i++) {
            JSONObject jsonObject = jsonArray.getJSONObject(i);
            String idDevice = jsonObject.getString("id_device");
            String time = jsonObject.getString("latest_time");

            addDataToTable(idDevice, time);
        }
    }

    private void addDataToTable(String idDevice, String time) {
        TableRow row = new TableRow(requireContext());
        TextView deviceIdTextView = new TextView(requireContext());
        TextView timeTextView = new TextView(requireContext());

        deviceIdTextView.setText(idDevice);
        timeTextView.setText(time);
        deviceIdTextView.setTextColor(Color.BLACK);
        timeTextView.setTextColor(Color.BLACK);

        row.addView(deviceIdTextView);
        row.addView(timeTextView);

        tableLayout.addView(row);
    }

    public void showDatePicker(View v) {
        EditText editText = (EditText) v;
        int year, month, day;

        // Get current date to initialize DatePickerDialog
        Calendar calendar = Calendar.getInstance();
        year = calendar.get(Calendar.YEAR);
        month = calendar.get(Calendar.MONTH);
        day = calendar.get(Calendar.DAY_OF_MONTH);

        // Show DatePickerDialog
        DatePickerDialog datePickerDialog = new DatePickerDialog(requireContext(), (view, selectedYear, selectedMonth, selectedDay) -> {
            String selectedDate = String.format(Locale.getDefault(), "%d-%02d-%02d", selectedYear, selectedMonth + 1, selectedDay);
            editText.setText(selectedDate);
        }, year, month, day);
        datePickerDialog.show();
    }
}
