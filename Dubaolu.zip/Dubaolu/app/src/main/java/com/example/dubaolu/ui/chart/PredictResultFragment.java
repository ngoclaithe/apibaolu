package com.example.dubaolu.ui.chart;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.example.dubaolu.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class PredictResultFragment extends Fragment {
    private static final MediaType JSON = MediaType.get("application/json; charset=utf-8");
    private String serverAddress;
    private Spinner locationSpinner;
    private TextView responseText;

    private final Map<String, String> locationMapping = new HashMap<String, String>() {{
        put("Hồ Chí Minh", "Ho Chi Minh");
        put("Hà Nội", "Ha Noi");
        put("Đà Nẵng", "Da Nang");
        put("Huế", "Hue");
        put("Hải Phòng", "Hai Phong");
    }};

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_predict, container, false);

        locationSpinner = root.findViewById(R.id.locationSpinner);
        responseText = root.findViewById(R.id.responseText);
        Button submitButton = root.findViewById(R.id.submitButton);

        String[] locations = {"Hồ Chí Minh", "Hà Nội", "Đà Nẵng", "Huế", "Hải Phòng"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                requireContext(),
                android.R.layout.simple_spinner_item,
                locations
        );
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        locationSpinner.setAdapter(adapter);

        SharedPreferences sharedPreferences = requireContext().getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
        serverAddress = sharedPreferences.getString("server_address", "");
        Log.d("serverAddress", serverAddress);

        submitButton.setOnClickListener(v -> {
            String location = locationSpinner.getSelectedItem().toString();
            if (!location.isEmpty()) {
                String mappedLocation = mapLocation(location);
                requestPredict(mappedLocation);
            } else {
                Toast.makeText(requireContext(), "Vui lòng chọn địa điểm", Toast.LENGTH_SHORT).show();
            }
        });

        return root;
    }

    private String mapLocation(String location) {
        return locationMapping.getOrDefault(location, location);
    }

    private void requestPredict(String location) {
        String url = serverAddress + "/predict/location";
        Log.d("URL", url);

        JSONObject jsonBody = new JSONObject();
        try {
            jsonBody.put("location", location);
        } catch (JSONException e) {
            e.printStackTrace();
            Toast.makeText(requireContext(), "Tạo JSON thất bại", Toast.LENGTH_SHORT).show();
            return;
        }

        RequestBody body = RequestBody.create(jsonBody.toString(), JSON);
        Request request = new Request.Builder()
                .url(url)
                .post(body)
                .build();

        OkHttpClient client = new OkHttpClient();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                e.printStackTrace();
                requireActivity().runOnUiThread(() ->
                        Toast.makeText(requireContext(), "Không thể lấy dữ liệu", Toast.LENGTH_SHORT).show()
                );
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                String responseData = response.body().string();
                requireActivity().runOnUiThread(() -> {
                    handleResponse(responseData);
                });
            }
        });
    }

    private void handleResponse(String responseData) {
        try {
            JSONObject jsonObject = new JSONObject(responseData);
            double predictedTemp = jsonObject.getDouble("predicted_temperature");
            int predictedHum = jsonObject.getInt("predicted_humidity");
            double actualTemp = jsonObject.getDouble("actual_temperature");
            int actualHum = jsonObject.getInt("actual_humidity");

            String formattedResponse = String.format(
                    "Dự đoán 6 tiếng tới:\n - Nhiệt độ: %.2f°C\n - Độ ẩm: %d%%\n\nThực tế:\n - Nhiệt độ: %.2f°C\n - Độ ẩm: %d%%",
                    predictedTemp, predictedHum, actualTemp, actualHum
            );
            responseText.setText(formattedResponse);
        } catch (JSONException e) {
            e.printStackTrace();
            responseText.setText("Phản hồi không hợp lệ");
        }
    }
}
