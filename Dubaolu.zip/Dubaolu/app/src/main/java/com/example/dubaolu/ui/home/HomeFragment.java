package com.example.dubaolu.ui.home;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;
import android.graphics.Color;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.example.dubaolu.R;
import com.example.dubaolu.databinding.FragmentHomeBinding;
import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class HomeFragment extends Fragment {

    private FragmentHomeBinding binding;
    private BarChart chart;
    private ArrayList<BarEntry> entries;
    private BarDataSet dataSet;
    private BarData barData;

    private DatabaseReference databaseReference;
    private com.orbitalsonic.waterwave.WaterWaveView waterWaveView;
    private TextView distanceTextView, flowRateTextView, rainStatusTextView;

    private Switch autoModeSwitch, hornSwitch, lightSwitch;
    private EditText distanceThresholdEditText, flowRateThresholdEditText, soilMoistureThresholdEditText;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        FirebaseDatabase database = FirebaseDatabase.getInstance("https://dubaolu-5559b-default-rtdb.asia-southeast1.firebasedatabase.app");
        databaseReference = database.getReference();

        binding = FragmentHomeBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        initializeViews(root);

        setupChart();

        attachFirebaseListeners();

        setupListeners();

        return root;
    }

    private void initializeViews(View root) {
        autoModeSwitch = root.findViewById(R.id.switch_auto_mode);
        hornSwitch = root.findViewById(R.id.switch_horn);
        lightSwitch = root.findViewById(R.id.switch_light);

        distanceThresholdEditText = root.findViewById(R.id.editTextDistanceThreshold);
        flowRateThresholdEditText = root.findViewById(R.id.editTextFlowRateThreshold);
        soilMoistureThresholdEditText = root.findViewById(R.id.editTextSoilMoistureThreshold);

        waterWaveView = root.findViewById(R.id.waterWaveView);

        distanceTextView = root.findViewById(R.id.distanceTextView);
        flowRateTextView = root.findViewById(R.id.flowRateTextView);
        rainStatusTextView = root.findViewById(R.id.rainStatusTextView);
    }

    private void setupChart() {
        chart = binding.chart1;
        chart.setDrawBarShadow(false);
        chart.setDrawValueAboveBar(true);
        chart.getDescription().setEnabled(false);
        chart.setMaxVisibleValueCount(30);
        chart.setPinchZoom(false);
        chart.setDrawGridBackground(false);
        chart.getXAxis().setPosition(XAxis.XAxisPosition.BOTTOM);

        entries = new ArrayList<>();
        dataSet = new BarDataSet(entries, "Lưu lượng nước (l/p)");
        dataSet.setColor(Color.RED);
        barData = new BarData(dataSet);
        chart.setData(barData);
    }

    private void attachFirebaseListeners() {
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    updateSensorData(snapshot);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.e("Firebase", "Error reading sensor data", error.toException());
            }
        });
    }

    private void updateSensorData(DataSnapshot snapshot) {
        if (snapshot.hasChild("distance")) {
            double distance = snapshot.child("distance").getValue(Double.class);
            distanceTextView.setText(String.format("Khoảng cách: %.2f cm", distance));
        }

        if (snapshot.hasChild("flowRate")) {
            double flowRate = snapshot.child("flowRate").getValue(Double.class);
            flowRateTextView.setText(String.format("Lưu lượng: %.2f l/p", flowRate));
            updateChart(flowRate);
        }

        if (snapshot.hasChild("soil")) {
            int soilValue = snapshot.child("soil").getValue(Integer.class);
            updateProgressBar(soilValue);
        }

        if (snapshot.hasChild("rainStatus")) {
            String rainStatus = snapshot.child("rainStatus").getValue(String.class);
            rainStatusTextView.setText("Trạng thái mưa: " + rainStatus);
        }
    }


    private void setupListeners() {
        autoModeSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            Map<String, Object> modeUpdate = new HashMap<>();
            modeUpdate.put("mode", isChecked ? "on" : "off");
            databaseReference.updateChildren(modeUpdate);
        });

        hornSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            databaseReference.child("hornState").setValue(isChecked ? "ON" : "OFF");
        });

        lightSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            databaseReference.child("lightState").setValue(isChecked ? "ON" : "OFF");
        });

        distanceThresholdEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}

            @Override
            public void afterTextChanged(Editable s) {
                try {
                    double threshold = Double.parseDouble(s.toString());
                    databaseReference.child("thresholds").child("distance").setValue(threshold);
                } catch (NumberFormatException e) {
                    distanceThresholdEditText.setError("Giá trị không hợp lệ");
                }
            }
        });

        flowRateThresholdEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}

            @Override
            public void afterTextChanged(Editable s) {
                try {
                    double threshold = Double.parseDouble(s.toString());
                    databaseReference.child("thresholds").child("flowRate").setValue(threshold);
                } catch (NumberFormatException e) {
                    flowRateThresholdEditText.setError("Giá trị không hợp lệ");
                }
            }
        });

        soilMoistureThresholdEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}

            @Override
            public void afterTextChanged(Editable s) {
                try {
                    double threshold = Double.parseDouble(s.toString());
                    databaseReference.child("thresholds").child("soilMoisture").setValue(threshold);
                } catch (NumberFormatException e) {
                    soilMoistureThresholdEditText.setError("Giá trị không hợp lệ");
                }
            }
        });
    }

    private void updateProgressBar(final float soilValue) {
        requireActivity().runOnUiThread(() -> {
            waterWaveView.setProgress((int) soilValue);
        });
    }

    private void updateChart(double flowRate) {
        entries.add(new BarEntry(entries.size(), (float) flowRate));

        if (entries.size() > 10) {
            entries.remove(0);
        }

        dataSet.setValues(entries);
        dataSet.notifyDataSetChanged();
        barData.notifyDataChanged();
        chart.notifyDataSetChanged();
        chart.invalidate();
    }
//    private void updateChart(float moisture) {
//        entries.add(new BarEntry(entries.size(), moisture));
//        dataSet.notifyDataSetChanged();
//        barData.notifyDataChanged();
//        chart.notifyDataSetChanged();
//        chart.invalidate();
//    }
    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
