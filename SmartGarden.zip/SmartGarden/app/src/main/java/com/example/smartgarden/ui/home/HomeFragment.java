package com.example.smartgarden.ui.home;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.animation.ObjectAnimator;
import androidx.annotation.Nullable;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.example.smartgarden.R;
import com.example.smartgarden.databinding.FragmentHomeBinding;
import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttMessage;

import java.util.ArrayList;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import java.io.IOException;

public class HomeFragment extends Fragment {

    private FragmentHomeBinding binding;
    private BarChart chart;
    private ArrayList<BarEntry> entries;
    private BarDataSet dataSet;
    private BarData barData;


    private MqttClient client;
    private String serverAddress;
    private com.orbitalsonic.waterwave.WaterWaveView waterWaveView;
    private float averageSoilMoisture = 0;
    private int numReadings = 0;
    private TextView textView;
    private Switch controlSwitch, modecontrol, controlLight;
    private Spinner startHour, startMinutes, endHour, endMinutes;
    private boolean autoModeEnabled = false;
    private OkHttpClient httpClient;
    private Button setHumi;
    private EditText editTextHumidity;


    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        SharedPreferences sharedPreferences = requireContext().getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
        serverAddress = sharedPreferences.getString("server_address", "");


        binding = FragmentHomeBinding.inflate(inflater, container, false);
        View root = binding.getRoot();
        controlSwitch = root.findViewById(R.id.switch_pump);
        modecontrol = root.findViewById(R.id.switch_auto_mode);
        waterWaveView = root.findViewById(R.id.waterWaveView);
        textView = root.findViewById(R.id.textView);
        startHour = root.findViewById(R.id.spinnerStartHour);
        startMinutes = root.findViewById(R.id.spinnerStartMinute);
        endHour = root.findViewById(R.id.spinnerEndHour);
        endMinutes = root.findViewById(R.id.spinnerEndMinute);
        controlLight = root.findViewById(R.id.switch_light);

        httpClient = new OkHttpClient();

        // Initialize chart
        chart = binding.chart1;
        chart.setDrawBarShadow(false);
        chart.setDrawValueAboveBar(true);
        chart.getDescription().setEnabled(false);
        chart.setMaxVisibleValueCount(30);
        chart.setPinchZoom(false);
        chart.setDrawGridBackground(false);
        chart.getXAxis().setPosition(XAxis.XAxisPosition.BOTTOM);

        entries = new ArrayList<>();


        dataSet = new BarDataSet(entries, "Độ ẩm đất (%)");
        barData = new BarData(dataSet);
        chart.setData(barData);

        // Connect to MQTT broker
        connectToMqttBroker();

        modecontrol.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                autoModeEnabled = isChecked;
                if (isChecked) {
                    // Auto mode is enabled, hide controlSwitch and send set_schedule request
                    controlSwitch.setVisibility(View.GONE);
                    String fromTime = startHour.getSelectedItem().toString()+":"+startMinutes.getSelectedItem().toString();
                    String toTime = endHour.getSelectedItem().toString()+":"+endMinutes.getSelectedItem().toString();
                    sendHttpRequest("set_schedule?from_time=" + fromTime + "&to_time=" + toTime);
                } else {
                    // Auto mode is disabled, show controlSwitch and send set_manual request
                    controlSwitch.setVisibility(View.VISIBLE);
                    sendHttpRequest("set_manual");
                }
            }
        });
        controlSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    // Send MQTT message with topic control/water/state and payload ON
                    sendMessageControlPumpToMqtt("control/water/state", "ON");
                } else {
                    // Send MQTT message with topic control/water/state and payload OFF
                    sendMessageControlPumpToMqtt("control/water/state", "OFF");
                }
            }
        });
        controlLight.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    // Send MQTT message with topic control/water/state and payload ON
                    sendMessageControlPumpToMqtt("control/water/state", "ONLIGHT");
                } else {
                    // Send MQTT message with topic control/water/state and payload OFF
                    sendMessageControlPumpToMqtt("control/water/state", "OFFLIGHT");
                }
            }
        });
        return root;
    }
    private void sendMessageControlPumpToMqtt(String topic, String payload) {
        try {
            if (client != null && client.isConnected()) {
                MqttMessage message = new MqttMessage(payload.getBytes());
                message.setQos(1);
                client.publish(topic, message);
                Log.d("MQTT", "Sent message - Topic: " + topic + ", Payload: " + payload);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    private void connectToMqttBroker() {
        try {
            String broker = "tcp://" + serverAddress + ":1883";
            client = new MqttClient(broker, MqttClient.generateClientId(), null);
            client.connect(new MqttConnectOptions());
            client.setCallback(new MqttCallback() {
                @Override
                public void connectionLost(Throwable cause) {
                    // Xử lý mất kết nối
                }

                @Override
                public void messageArrived(String topic, MqttMessage message) {
                    if (topic.equals("state/soilmoisture")) {
                        float moisture = Float.parseFloat(new String(message.getPayload()));
                        updateChart(moisture);
                        averageSoilMoisture = (averageSoilMoisture * numReadings + moisture) / (numReadings + 1);
                        numReadings++;

                        // Cập nhật ProgressBar
                        updateProgressBar(averageSoilMoisture);
                    } else if (topic.equals("state/percentwater")) {
                        float percentWater = Float.parseFloat(new String(message.getPayload()));
                        updateWaterWaveView(percentWater);
                    }
                }

                @Override
                public void deliveryComplete(IMqttDeliveryToken token) {

                }
            });
            client.subscribe("state/soilmoisture");
            client.subscribe("state/percentwater");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    private void updateProgressBar(final float averageMoisture) {
        getActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                int progress = (int) averageMoisture;
                textView.setText(String.valueOf(progress));
                Log.d("ProgressBar", "Average Soil Moisture: " + progress + ", Num Readings: " + numReadings);
            }
        });
    }



    private void updateChart(float moisture) {
        entries.add(new BarEntry(entries.size(), moisture));
        dataSet.notifyDataSetChanged();
        barData.notifyDataChanged();
        chart.notifyDataSetChanged();
        chart.invalidate();
        for (BarEntry entry : entries) {
            Log.d("Entry", "X: " + entry.getX() + ", Y: " + entry.getY());
        }
    }

    private void updateWaterWaveView(float percentWater) {
        int progress = (int) percentWater;
        waterWaveView.setProgress(progress);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
        try {
            if (client != null && client.isConnected()) {
                client.disconnect();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    private void sendHttpRequest(String request) {
        String url = "http://" + serverAddress + ":8000/" + request;

        Request httpRequest = new Request.Builder()
                .url(url)
                .get()
                .build();

        httpClient.newCall(httpRequest).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                // Handle failure
                e.printStackTrace();
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                // Handle response
                if (!response.isSuccessful()) {

                    Log.e("HTTP Request", "Request failed: " + response.code());
                }

                response.close();
            }
        });
    }
}
